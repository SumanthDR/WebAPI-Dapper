﻿using App.Entities;
using App.Entities.RequestModel;

namespace App.Service.IService
{
    public interface ICardsService
    {
        /// <summary>
        /// GetAllCards
        /// </summary>
        /// <returns></returns>
        Task<List<Cards>> GetAllCards();
        /// <summary>
        /// GetCardById
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<Cards> GetCardById(int id);
        /// <summary>
        /// UpdateCardById
        /// </summary>
        /// <param name="updateCardRequestModel"></param>
        /// <returns></returns>
        Task<Cards> UpdateCardById(UpdateCardRequestModel updateCardRequestModel);
        /// <summary>
        /// CreateCard
        /// </summary>
        /// <param name="cards"></param>
        /// <returns></returns>
        Task<Cards> CreateCard(Cards cards);
        /// <summary>
        /// DeleteCardById
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<bool> DeleteCardById(int id);
        /// <summary>
        /// SoftDeleteCardById
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        Task<Cards> SoftDeleteCardById(int Id);
    }
}
