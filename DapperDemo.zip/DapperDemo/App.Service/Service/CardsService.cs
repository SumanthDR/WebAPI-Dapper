﻿using App.Entities;
using App.Entities.RequestModel;
using App.Repository.IRepository;
using App.Service.IService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace App.Service.Service
{
    public class CardsService : ICardsService
    {
        private readonly ICardsRepository _cardsRepository;
        public CardsService(ICardsRepository cardsRepository)
        {
            _cardsRepository = cardsRepository;
        }

        public async Task<List<Cards>> GetAllCards()
        {
            var result = await _cardsRepository.GetAllCards();
            return result;
        }
        public async Task<Cards> GetCardById(int id)
        {
            var result = await _cardsRepository.GetCardById(id);
            return result;
        }        
        public async Task<Cards> UpdateCardById(UpdateCardRequestModel updateCardRequestModel)
        {
            var result = await _cardsRepository.UpdateCardById(updateCardRequestModel);
            return result;
        }
        public async Task<Cards> CreateCard(Cards cards)
        {
            var result = await _cardsRepository.CreateCard(cards);
            return result;
        }        
        public async Task<bool> DeleteCardById(int id)
        {
            var result = await _cardsRepository.DeleteCardById(id);
            return result;
        }
        public async Task<Cards> SoftDeleteCardById(int Id)
        {
            var result = await _cardsRepository.SoftDeleteCardById(Id);
            return result;
        }
    }
}
