﻿using App.Entities.RequestModel;
using App.Service.IService;
using Microsoft.AspNetCore.Mvc;

namespace App.Web.Controllers.Cards
{
    [ApiController]
    [Route("api/[controller]")]
    public class CardsController : Controller
    {
        private readonly ICardsService _cardsService;
        public CardsController(ICardsService cardsService)
        {
            _cardsService = cardsService;
        }

        [HttpGet("GetAllCards")]
        public async Task<IActionResult> GetAllCards()
        {
            var result = await _cardsService.GetAllCards();
            return Ok(result);
        }

        [HttpGet("GetCardById/{id}")]
        public async Task<IActionResult> GetCardById(int id)
        {
            var result = await _cardsService.GetCardById(id);
            return Ok(result);
        }

        [HttpPost("SaveCard")]
        public async Task<IActionResult> CreateCard(App.Entities.Cards cards)
        {
            var result = await _cardsService.CreateCard(cards);
            return Ok(result);
        }

        [HttpPut("UpdateCard")]
        public async Task<IActionResult> UpdateCard(UpdateCardRequestModel updateCardRequestModel)
        {
            var result = await _cardsService.UpdateCardById(updateCardRequestModel);
            return Ok(result);
        }

        [HttpPut("SoftDeleteCardById/{id}")]
        public async Task<IActionResult> SoftDeleteCardById(int id)
        {
            var result = await _cardsService.SoftDeleteCardById(id);
            return Ok(result);
        }

        [HttpDelete("DeleteCardById/{id}")]
        public async Task<IActionResult> DeleteCardById(int id)
        {
            var result = await _cardsService.DeleteCardById(id);
            return Ok(result);
        }
    }
}