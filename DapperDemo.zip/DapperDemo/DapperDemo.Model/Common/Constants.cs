﻿namespace App.Entities.Common
{
    public class Constants
    {
        public class CardsSP
        {
            /// <summary>
            /// SpGetAllActiveCards
            /// </summary>
            public const string SpGetAllActiveCards = "SpGetAllActiveCards";
            /// <summary>
            /// SpGetCardById 
            /// </summary>
            public const string SpGetCardById = "SpGetCardById";
            /// <summary>
            /// SpUpdateCardById
            /// </summary>
            public const string SpUpdateCardById = "SpUpdateCardById";
            /// <summary>
            /// SpInsertCard 
            /// </summary>
            public const string SpInsertCard = "SpInsertCard";
            /// <summary>
            /// SpSoftDeleteCardById
            /// </summary>
            public const string SpSoftDeleteCardById = "SpSoftDeleteCardById";
            /// <summary>
            /// SpDeleteCardById
            /// </summary>
            public const string SpDeleteCardById = "SpDeleteCardById";
        }
    }
}
