﻿CREATE PROCEDURE [dbo].[SpDeleteCardById]
	@Id int = 0
AS
	IF EXISTS(SELECT COUNT(*) FROM Cards WHERE Id = @Id)
	BEGIN
		DELETE FROM Cards WHERE Id = @Id;

		SELECT * FROM Cards WHERE Id = @Id;
	END
	ELSE
	BEGIN
		SELECT 'Record not found !' AS Message;
	END
GO
