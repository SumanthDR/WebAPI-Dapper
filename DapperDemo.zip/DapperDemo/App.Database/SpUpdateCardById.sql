﻿CREATE PROCEDURE [dbo].[SpUpdateCardById]
	@Id int = 0,
	@Name VARCHAR(50),
	@Description VARCHAR(50)
AS		
	IF EXISTS (SELECT COUNT(Id) FROM Cards WHERE Id = @Id)
	BEGIN
		UPDATE Cards SET 
		Name = @Name,
		Description = @Description,
		UpdatedDateTime = GETDATE()
		WHERE Id = @Id;

		SELECT * FROM Cards WHERE Id = @Id;
	END
	ELSE
	BEGIN
		SELECT 'Record Not Found !' AS Message;
	END		
GO