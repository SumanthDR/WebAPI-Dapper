﻿CREATE PROCEDURE [dbo].[SpGetCardById]
	@Id int = 0
AS
	SELECT Id, Name, Description, IsActive, CreatedDateTime, UpdatedDateTime FROM dbo.Cards WHERE IsActive = 1 AND Id = @Id;
GO