﻿CREATE PROCEDURE [dbo].[SpSoftDeleteCardById]
	@Id int = 0	
AS
BEGIN
	IF EXISTS(SELECT COUNT(*) FROM Cards WHERE Id = @Id)
	BEGIN
		UPDATE Cards SET IsActive = 0 WHERE Id = @Id;

		SELECT * FROM Cards WHERE Id = @Id;
	END
	ELSE
	BEGIN
		SELECT 'Record not found !' AS Message;
	END
END