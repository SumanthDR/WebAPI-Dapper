﻿CREATE PROCEDURE [dbo].[SpGetAllActiveCards]	
AS
	SELECT Id, Name, Description, IsActive, CreatedDateTime, UpdatedDateTime FROM dbo.Cards WHERE IsActive = 1
	ORDER BY CreatedDateTime;
GO