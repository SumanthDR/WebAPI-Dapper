﻿CREATE PROCEDURE [dbo].[SpInsertCard]
(
	@Name VARCHAR(50),
	@Description VARCHAR(50)
)	
AS
	DECLARE @InsertedID INT;
	INSERT INTO Cards (Name, Description, IsActive, CreatedDateTime)
	VALUES (@Name, @Description, 1, GETDATE());	

	SET @InsertedID = SCOPE_IDENTITY();

	SELECT * FROM Cards WHERE Id = @InsertedID;
GO