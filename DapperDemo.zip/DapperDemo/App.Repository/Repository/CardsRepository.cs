﻿using App.Entities;
using App.Entities.Common;
using App.Entities.RequestModel;
using App.Repository.IRepository;
using Dapper;

namespace App.Repository.Repository
{
    public class CardsRepository:ICardsRepository
    {
        private readonly DbContext _dbContext;
        
        public CardsRepository(DbContext dbContext)
        {            
            _dbContext = dbContext;
        }

        public async Task<List<Cards>> GetAllCards()
        {   
            try
            {
                using (var connection = _dbContext.CreateConnection())
                {
                    var cards = await connection.QueryAsync<Cards>(Constants.CardsSP.SpGetAllActiveCards,null,commandType:System.Data.CommandType.StoredProcedure);

                    return cards.ToList();
                }
            }
            catch(Exception ex)
            {
                return null;
            }
        }

        public async Task<Cards> GetCardById(int id)
        {
            try
            {
                using (var connection = _dbContext.CreateConnection())
                {
                    var parameter = new DynamicParameters();
                    parameter.Add("Id", id);

                    var card = await connection.QueryFirstAsync<Cards>(Constants.CardsSP.SpGetCardById, parameter, commandType: System.Data.CommandType.StoredProcedure);

                    return card;
                }
            }
            catch (Exception ex) 
            {
                return null;
            }            
        }

        public async Task<Cards> UpdateCardById(UpdateCardRequestModel updateCardRequestModel)
        {
            try
            {
                using (var connection = _dbContext.CreateConnection())
                {
                    var parameter = new DynamicParameters();
                    parameter.Add("Id", updateCardRequestModel.Id);
                    parameter.Add("Name", updateCardRequestModel.Name);
                    parameter.Add("Description", updateCardRequestModel.Description);

                    var card = await connection.QueryFirstAsync<Cards>(Constants.CardsSP.SpUpdateCardById, parameter, commandType: System.Data.CommandType.StoredProcedure);

                    return card;
                }
            }
            catch (Exception ex) { return null; }
        }

        public async Task<Cards> CreateCard(Cards cards)
        {
            try
            {
                using (var connection = _dbContext.CreateConnection())
                {
                    var parameter = new DynamicParameters();                    
                    parameter.Add("Name", cards.Name);
                    parameter.Add("Description", cards.Description);

                    var card = await connection.QueryFirstOrDefaultAsync<Cards>(Constants.CardsSP.SpInsertCard, parameter, commandType: System.Data.CommandType.StoredProcedure);

                    return card;
                }
            }
            catch (Exception ex) { return null; }
        }

        public async Task<bool> DeleteCardById(int id)
        {
            try
            {
                using (var connection = _dbContext.CreateConnection())
                {
                    var parameter = new DynamicParameters();
                    parameter.Add("Id", id);
                    
                    var card = await connection.ExecuteAsync(Constants.CardsSP.SpDeleteCardById, parameter, commandType: System.Data.CommandType.StoredProcedure);

                    return true;
                }
            }
            catch (Exception ex) { return false; }
        }

        public async Task<Cards> SoftDeleteCardById(int Id)
        {
            try
            {
                using (var connection = _dbContext.CreateConnection())
                {
                    var parameter = new DynamicParameters();
                    parameter.Add("Id", Id);
                    
                    var card = await connection.QueryFirstAsync<Cards>(Constants.CardsSP.SpSoftDeleteCardById, parameter, commandType: System.Data.CommandType.StoredProcedure);

                    return card;
                }
            }
            catch (Exception ex) { return null; }
        }
    }
}